package com.example.tiktokrepostcleaner

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class RepostAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private val removeLabels = listOf(
        "remove repost", "remove reposting", "удалить репост", "отменить репост",
        "убрать репост", "repost entfernen", "retirer le repost", "eliminar republicación"
    )
    private val confirmLabels = listOf("remove", "удалить", "confirm", "подтвердить")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName !in setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 1800) return
        val root = rootInActiveWindow ?: return
        val candidate = findLabel(root, removeLabels)
        if (candidate != null && candidate.isEnabled) {
            lastActionAt = now
            candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // Intentionally does not tap generic confirmation buttons: user must confirm dialogs.
    }

    private fun findLabel(node: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val text = (node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")
        val normalized = text.lowercase().trim()
        if (labels.any { normalized == it || normalized.contains(it) }) {
            if (node.isClickable) return node
            val parent = node.parent
            if (parent != null && parent.isClickable) return parent
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findLabel(child, labels)
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() {}
}
