package com.example.tiktokrepostcleaner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Repost Helper для TikTok"
            textSize = 24f
        }
        val description = TextView(this).apply {
            text = "\nПомощник ищет только явную кнопку «Удалить репост / Remove repost» на экране TikTok. Открой репост и меню «Поделиться» вручную. Автоматическое массовое удаление не гарантируется; проверь каждое действие."
            textSize = 16f
        }
        val accessibility = Button(this).apply {
            text = "1. Включить службу помощника"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val openTikTok = Button(this).apply {
            text = "2. Открыть TikTok"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
                    ?: packageManager.getLaunchIntentForPackage("com.ss.android.ugc.trill")
                if (launch != null) startActivity(launch)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/")))
            }
        }
        val how = TextView(this).apply {
            text = "\nКак пользоваться:\n1) Включи Repost Helper в специальных возможностях Android.\n2) Открой свой профиль TikTok и выбери репост.\n3) Открой меню «Поделиться». Если TikTok показывает явную кнопку удаления репоста, помощник нажмёт её.\n4) Проверь результат и повтори для следующего видео.\n\nПомощник не запрашивает пароль и не отправляет данные куда-либо."
            textSize = 14f
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(accessibility, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(openTikTok, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(how)
        setContentView(layout)
    }
}
